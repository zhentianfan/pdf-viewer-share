"use strict";
window.addEventListener("hashchange", () => {
  if (window.location.hash) window.location.reload();
});
(async () => {
  let fragment = window.location.hash.slice(1);
  history.replaceState(null, "", window.location.pathname + window.location.search);
  const status = document.getElementById("status");
  let blobUrl;
  let keyBytes;
  try {
    if (!window.crypto?.subtle) throw new Error("unavailable");
    const params = new URLSearchParams(fragment);
    fragment = "";
    const fields = [...params.keys()];
    if (fields.length !== 3 || !["id", "key", "name"].every(k => params.getAll(k).length === 1)) throw new Error("invalid");
    const id = params.get("id");
    let encodedKey = params.get("key");
    const name = params.get("name");
    params.delete("key");
    if (!/^[a-f0-9]{32}$/.test(id) || !/^[A-Za-z0-9_-]{43}$/.test(encodedKey) || !/^certificate\.[A-Z0-9]+\.[A-Z0-9]+\.HA\.pdf$/.test(name)) throw new Error("invalid");
    keyBytes = Uint8Array.from(atob(encodedKey.replace(/-/g, "+").replace(/_/g, "/") + "="), c => c.charCodeAt(0));
    encodedKey = null;
    if (keyBytes.byteLength !== 32) throw new Error("invalid");
    const key = await crypto.subtle.importKey("raw", keyBytes, { name: "AES-GCM" }, false, ["decrypt"]);
    keyBytes.fill(0);
    status.textContent = "正在本地解密文档…";
    const response = await fetch(new URL("data/" + id + ".bin", window.location.href), { cache: "no-store", credentials: "omit", referrerPolicy: "no-referrer" });
    if (!response.ok) throw new Error("unavailable");
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes.byteLength < 29) throw new Error("invalid");
    const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bytes.slice(0, 12), tagLength: 128 }, key, bytes.slice(12));
    const signature = new Uint8Array(plain, 0, Math.min(5, plain.byteLength));
    if (String.fromCharCode(...signature) !== "%PDF-") throw new Error("invalid");
    blobUrl = URL.createObjectURL(new Blob([plain], { type: "application/pdf" }));
    const viewerUrl = new URL("pdfjs/web/viewer.html", window.location.href);
    viewerUrl.searchParams.set("file", blobUrl);
    viewerUrl.hash = "zoom=page-width";
    const frame = document.getElementById("pdf-frame");
    document.getElementById("file-name").textContent = name;
    frame.src = viewerUrl.href;
    frame.hidden = false;
    status.hidden = true;
    window.addEventListener("pagehide", () => URL.revokeObjectURL(blobUrl), { once: true });
  } catch {
    if (keyBytes) keyBytes.fill(0);
    if (blobUrl) URL.revokeObjectURL(blobUrl);
    status.textContent = "无法打开文档。请使用完整的专用扫码链接重试。";
  }
})();
